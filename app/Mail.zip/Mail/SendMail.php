<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SendMail extends Mailable
{
    use Queueable, SerializesModels;

    public $name;
    public $package;
    public $passenger;
    public $amount;
    public $service;
    public $pdfContent;

    /**
     * Create a new message instance.
     *
     * @param string $name
     * @return void
     */
    public function __construct($name, $service, $package, $passenger, $amount, $pdfContent)
    {
        //
        $this->name = $name;
        $this->service = $service;
        $this->package = $package;
        $this->passenger = $passenger;
        $this->amount = $amount;
        $this->pdfContent = $pdfContent;
        
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        //return $this->view('view.name');
        return $this->from('info@travelwheel.ng', 'Travel Wheel')
                    ->subject('TRAVEL WHEEL BOOKINGS')
                    ->view('emails.send')
                    ->with([
                        'name' => $this->name,
                        'service' => $this->service,
                        'package' => $this->package,
                        'passenger' => $this->passenger,
                        'amount' => $this->amount,
                        
                    ])
                    ->attachData($this->pdfContent, 'document.pdf', [
                        'mime' => 'application/pdf',
                    ]);
    }
}
