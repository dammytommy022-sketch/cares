# Changelog

## 2.0.0 - 2023-02-28

- This version updates support for PHP version 8.0 and above
## 2.0.1 - 2023-03-02

- Minor updates and bug fixes
