<?php

if (! function_exists("seerbit"))
{
    function seerbit() {

        return app()->make('seerbit');
    }
}
