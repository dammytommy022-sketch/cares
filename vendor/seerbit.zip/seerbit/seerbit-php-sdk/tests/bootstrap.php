<?php

\define('SEERBIT_PUBLIC_KEY', getenv('SEERBIT_PUBLIC_KEY'));
\define('SEERBIT_SECRET_KEY', getenv('SEERBIT_SECRET_KEY'));
\define('SEERBIT_TOKEN', getenv('SEERBIT_TOKEN'));