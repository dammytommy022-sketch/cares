# Changelog

## 2.0.0 - 2020-02-01

- initial release


## 2.1.0 - 2020-08-06

- Updates to integration examples


## 2.2.0 - 2020-08-09

- A few examples update - minor changes

## 2.3.0 - 2021-02-09

- Change Monolog versioning

## 2.3.1 - 2023-02-28

- This version updates support for version 8.0 and above


## 2.3.2 - 2023-03-02
- Updates and bug fixes

## 2.3.4 - 2023-03-13
- Update transaction status validation

## 2.3.5 - 2023-03-15
- Bug fixes