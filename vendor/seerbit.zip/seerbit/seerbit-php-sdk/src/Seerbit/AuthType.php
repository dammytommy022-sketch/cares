<?php

namespace Seerbit;

class AuthType
{
    const BASIC = "Basic";
    const BEARER = "Bearer";
}