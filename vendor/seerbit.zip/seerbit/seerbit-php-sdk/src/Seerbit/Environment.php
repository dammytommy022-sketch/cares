<?php

namespace Seerbit;

class Environment
{
    const PILOT = "pilot";
    const LIVE = "live";
}

