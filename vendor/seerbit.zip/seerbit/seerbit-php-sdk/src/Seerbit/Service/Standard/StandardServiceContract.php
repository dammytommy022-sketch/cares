<?php

namespace Seerbit\Service\Standard;

interface StandardServiceContract {

    public function Initialize(array $payload);
}