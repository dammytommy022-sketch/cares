<?php
namespace Seerbit\Service;

interface IAuthenticate
{
//    public function Auth();
}